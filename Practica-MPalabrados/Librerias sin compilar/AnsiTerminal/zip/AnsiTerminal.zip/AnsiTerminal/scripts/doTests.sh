#!/bin/bash
# Load configuration & moves to the project root folder
if [ -d scripts ]
then
    source scripts/doConfig.sh
else
    source doConfig.sh
fi
echo "Generating fresh binaries"
make build
echo "Press [RETURN] to continue"
read
if [ $USE_VALGRIND = "YES" ]
then 
    VALGRIND="valgrind --leak-check=full "
else
    VALGRIND=""
fi
DIST=dist/Debug/GNU-Linux/
BINARY=$(ls $DIST)
FULL_BINARY=$VALGRIND$PROJECT_FOLDER/$DIST/$BINARY
cuenta=1
for test in $TESTS_FOLDER/*
do
    echo "Test #$cuenta ($BINARY < $test)"
    $FULL_BINARY < "$test"
    echo "END OF RUN"
    echo "Press [RETURN] to continue"
    read
    clear;
    cuenta=$[cuenta + 1]
done 
