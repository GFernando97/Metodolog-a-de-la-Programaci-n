#!/bin/bash
# Load configuration & moves to the project root folder
if [ -d scripts ]
then
    source scripts/doConfig.sh
else
    source doConfig.sh
fi
echo "Cleaning up temporary files in folders"
# Cleans binaries and precompiled files
make clobber 
# Cleans documentation folder, if it exists
CleanFolder $DOC_FOLDER/html
CleanFolder $DOC_FOLDER/latex
CleanFolder $ZIP_FOLDER
# Zips the project	
echo "Zipping project"
cd ..
zip -x $EXCLUDED_FOLDERS -r $PROJECT/$ZIP_FOLDER/$PROJECT.zip $PROJECT/* 
