#!/bin/bash
# Moves to the project' root folder
function CDRootFolder() {   
    DOMOVE=false
    while [ ! -d nbproject ]
    do
        cd ..
        DOMOVE=true
        DIR=$(pwd)
        if [ $DIR == '/' ] 
        then
            exit 1
        fi
    done 
    if [ "$DOMOVE" = true ]
    then
        echo "Moving down to project root folder "$(pwd)
    fi
}

# Check if folder exists, otherwise creates it or set it to default
# param $1 The folder to check
# param $2 The variable used to store $1 (reference)
function CheckFolder() {
    if [ ! $1 ] || [ ! $2 ]
    then
       echo "ERROR: Missing parameters to CheckFolder() "; echo
       exit 1
    fi
    FOLDER=/dev/null
    if [ ! -d $1 ]
    then
        if [ $CREATE_FOLDERS = "YES" ]
        then 
            echo "Creating folder "$1
            mkdir $1
            FOLDER=$1
        else
            echo "Folder $1 does not exist"
        fi
    else
        FOLDER=$1
    fi
    eval "$2=$FOLDER"
}

# Cleans folder
function CleanFolder() {
    if [ ! $1 ]
    then
       echo "ERROR: Missing parameter to CleanFolder() "; echo
       exit 1
    fi
    if [ -d $1/nbproject ]
    then
        echo "Sorry! Root folder cannot be cleaned up"
        exit 1
    fi
    if [ -d $1 ]
    then
        echo "Cleaning folder "$1
        rm -rf $1/*
    else
        echo "Folder $1 does not exist"
    fi
}


# Main
# Moves to root folder
CDRootFolder
# Reads root folder and its name
PROJECT_FOLDER=$(pwd)
PROJECT=$(basename $PROJECT_FOLDER)
# Create unexisting folders when required or not
CREATE_FOLDERS=YES
# Folders not to be included in the zip
EXCLUDED_FOLDERS=$PROJECT/nbproject/private/*
# Folder to store the zip
CheckFolder zip/ ZIP_FOLDER
# Folder to store Doxygen' data
CheckFolder doc/ DOC_FOLDER
# Folder to store test data
CheckFolder tests/ TESTS_FOLDER
# Use of memory leak detector
USE_VALGRIND=NO