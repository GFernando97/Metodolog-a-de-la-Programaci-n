var searchData=
[
  ['language',['Language',['../classLanguage.html#a09448361f9188bceaaeebc5576cd6896',1,'Language::Language()'],['../classLanguage.html#ad7c92d28e44058ef4c7ea1b413a4b269',1,'Language::Language(std::string language)']]]
];
