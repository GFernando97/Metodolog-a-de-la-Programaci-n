var searchData=
[
  ['query',['query',['../classLanguage.html#a677a05e98da32c5c54b6bf6343f80e21',1,'Language']]]
];
