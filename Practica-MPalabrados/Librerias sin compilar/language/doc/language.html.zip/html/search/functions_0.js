var searchData=
[
  ['getfrequency',['getFrequency',['../classLanguage.html#a39a391f8edca1cbdfeea606d968f2c4a',1,'Language']]],
  ['getlanguage',['getLanguage',['../classLanguage.html#ac78d5ca1b8305425b3343b53dca48b25',1,'Language']]],
  ['getletterset',['getLetterSet',['../classLanguage.html#a8c26af3042d9808963f05450f2d28f7e',1,'Language']]],
  ['getscore',['getScore',['../classLanguage.html#aa750e6f524fc6a51d0ef82dee5826fbf',1,'Language']]]
];
