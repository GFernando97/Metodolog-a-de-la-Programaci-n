var searchData=
[
  ['setlanguage',['setLanguage',['../classLanguage.html#accc1c22d8bba3002a71bea06cecf624b',1,'Language']]]
];
